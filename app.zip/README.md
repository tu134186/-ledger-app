# 巨魔工具箱 TrollBox

版本：1.0.0

这是独立的 TrollStore 工具箱工程，不包含原记账本项目的页面、Widget、App Group、iCloud 备份或记账逻辑。

## 工程
- `TrollBox.xcodeproj`：可直接用 Xcode 打开
- `project.yml`：如使用 XcodeGen，可重新生成工程
- Deployment Target：iOS 16.0
- Bundle ID：`com.trollbox.toolkit`
- URL Scheme：`trollbox://`

## 当前结构
- `TrollBox/index.html`：工具箱首页
- `TrollBox/AppDelegate.swift`
- `TrollBox/ViewController.swift`
- `TrollBox/Info.plist`
- `TrollBox/TrollBox.entitlements`
- `TrollBox/Assets.xcassets`
- `TrollBox/LaunchScreen.storyboard`

## 注意
本版本先保证工程结构干净、可编辑；后续再逐项加入巨魔环境检测、IPA 体检等功能。
