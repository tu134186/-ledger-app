# 巨魔工具箱 TrollBox

一个面向 TrollStore 用户的 iOS 工具箱。

## 当前版本

- App：1.0.0
- 最低系统：iOS 16.0
- App 名称：巨魔工具箱
- Bundle ID：com.trollbox.toolkit

## 当前功能

- TrollStore / IPA / 插件资源分类
- 应用与教程搜索
- 应用详情与下载入口
- 收藏与浏览历史
- 新手教程
- 本地数据保存

## 后续开发方向

1. 巨魔环境一键体检
2. IPA 体检与信息查看
3. 已安装 App 信息查看
4. Bundle ID / Team ID / Entitlements 查看
5. 常见安装问题自动诊断

本项目不包含日常记账、代收记账或记账小组件功能。
