# 巨魔工具箱

这是给仓库 GitHub Actions 使用的 `app.zip` 工程包。

- 工程名 / Scheme：Ledger
- 输出 App：Ledger.app
- App 显示名称：巨魔工具箱
- iOS：16.0+
- 版本：1.0.0
- 不包含 Widget、App Group、iCloud、记账页面

上传为仓库根目录的 `app.zip` 后，可使用现有 GitHub Actions 通过 XcodeGen 生成 `Ledger.xcodeproj` 并构建 `Ledger.app` / `Ledger.ipa`。


## V1.2.0
- 新增 IPA 一键体检
- 支持从“文件”App 选择 `.ipa`
- 检查 Payload / .app / Info.plist / Bundle ID / 版本 / Build / Mach-O 等可读取信息
- 不把“结构正常”冒充成“100% 可安装”
