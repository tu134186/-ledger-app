import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    var pendingURL: URL?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        let window = UIWindow(frame: UIScreen.main.bounds)
        let viewController = ViewController()
        window.rootViewController = viewController
        window.makeKeyAndVisible()
        self.window = window

        if let url = pendingURL {
            viewController.handleDeepLink(url)
            pendingURL = nil
        }
        return true
    }

    func application(_ app: UIApplication, open url: URL, options: [UIApplication.LaunchOptionsKey : Any] = [:]) -> Bool {
        if let viewController = window?.rootViewController as? ViewController {
            viewController.handleDeepLink(url)
        } else {
            pendingURL = url
        }
        return true
    }
}
