import UIKit
import WebKit
import UserNotifications
import UniformTypeIdentifiers
import zlib

final class ViewController: UIViewController, WKNavigationDelegate, WKScriptMessageHandler, UNUserNotificationCenterDelegate, UIDocumentPickerDelegate {
    private var webView: WKWebView!

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white

        let configuration = WKWebViewConfiguration()
        let userContentController = WKUserContentController()
        userContentController.add(self, name: "shareFile")
        userContentController.add(self, name: "requestNotification")
        userContentController.add(self, name: "deviceHealth")
        userContentController.add(self, name: "pickIPA")
        configuration.userContentController = userContentController

        webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = self
        webView.translatesAutoresizingMaskIntoConstraints = false
        webView.scrollView.bounces = false
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.scrollView.alwaysBounceVertical = false
        webView.scrollView.alwaysBounceHorizontal = false
        webView.scrollView.showsVerticalScrollIndicator = false
        webView.scrollView.showsHorizontalScrollIndicator = false
        webView.isOpaque = true
        webView.backgroundColor = .white
        view.addSubview(webView)

        NSLayoutConstraint.activate([
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            webView.topAnchor.constraint(equalTo: view.topAnchor),
            webView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])

        UNUserNotificationCenter.current().delegate = self
        loadHome()
    }

    private func loadHome() {
        guard let url = Bundle.main.url(forResource: "index", withExtension: "html") else { return }
        webView.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
    }

    func handleDeepLink(_ url: URL) {
        // Keep the scheme available for future toolbox shortcuts, but always return to the toolbox home.
        loadHome()
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        switch message.name {
        case "requestNotification":
            UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { _, _ in }
        case "deviceHealth":
            let iosVersion = UIDevice.current.systemVersion
            let model = UIDevice.current.model
            let appVersion = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "未知"
            let build = Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "未知"

            // Prefer LaunchServices inspection: TrollStore 2 can use a randomized/stealth
            // bundle identifier, so checking only one URL scheme is not reliable.
            var trollstoreInstalled = false
            var trollstoreDetection = "未检测到"
            if let workspaceClass = NSClassFromString("LSApplicationWorkspace") as? NSObject.Type,
               let workspace = workspaceClass.perform(NSSelectorFromString("defaultWorkspace"))?.takeUnretainedValue() as? NSObject,
               let apps = workspace.perform(NSSelectorFromString("allApplications"))?.takeUnretainedValue() as? [AnyObject] {
                for item in apps {
                    guard let app = item as? NSObject else { continue }
                    let bundleID = (app.value(forKey: "applicationIdentifier") as? String) ?? (app.value(forKey: "bundleIdentifier") as? String) ?? ""
                    let name = (app.value(forKey: "localizedName") as? String) ?? ""
                    if bundleID == "com.opa334.TrollStore" || bundleID.hasPrefix("com.opa334.TrollStore.TS_") || name.caseInsensitiveCompare("TrollStore") == .orderedSame {
                        trollstoreInstalled = true
                        trollstoreDetection = "通过系统应用列表检测到 TrollStore"
                        break
                    }
                }
            }

            // Fallbacks for environments where LaunchServices enumeration is restricted.
            let legacySchemeAvailable = UIApplication.shared.canOpenURL(URL(string: "trollstore://")!)
            if !trollstoreInstalled && legacySchemeAvailable {
                trollstoreInstalled = true
                trollstoreDetection = "检测到 TrollStore URL Scheme"
            }
            let magnifierSchemeAvailable = UIApplication.shared.canOpenURL(URL(string: "apple-magnifier://")!)
            if !trollstoreInstalled && magnifierSchemeAvailable {
                trollstoreDetection = "检测到系统 apple-magnifier://，无法单独证明 TrollStore 已安装"
            }

            let payload: [String: Any] = [
                "iosVersion": iosVersion,
                "deviceModel": model,
                "appVersion": appVersion,
                "build": build,
                "trollstoreInstalled": trollstoreInstalled,
                "trollstoreDetection": trollstoreDetection,
                "trollstoreSchemeState": legacySchemeAvailable ? "legacy" : (magnifierSchemeAvailable ? "apple-magnifier" : "none"),
                "webKit": true
            ]


        case "pickIPA":
            let picker = UIDocumentPickerViewController(forOpeningContentTypes: [UTType(filenameExtension: "ipa") ?? .data], asCopy: true)
            picker.delegate = self
            picker.allowsMultipleSelection = false
            present(picker, animated: true)

        case "shareFile":
            guard let data = message.body as? [String: String],
                  let content = data["content"],
                  let filename = data["filename"] else { return }
            let fileURL = FileManager.default.temporaryDirectory.appendingPathComponent(filename)
            do {
                try content.write(to: fileURL, atomically: true, encoding: .utf8)
                let controller = UIActivityViewController(activityItems: [fileURL], applicationActivities: nil)
                controller.popoverPresentationController?.sourceView = view
                present(controller, animated: true)
            } catch {
                return
            }
        default:
            break
        }
    }


    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let url = urls.first else { return }
        do {
            let data = try Data(contentsOf: url)
            let report = try IPAInspector.inspect(data: data, filename: url.lastPathComponent)
            sendIPAReport(report)
        } catch {
            sendIPAReport([
                "filename": url.lastPathComponent,
                "fileSize": 0,
                "entryCount": 0,
                "appFound": false,
                "issues": ["无法读取 IPA：文件无法访问或格式不正确，请重新选择完整的 .ipa 文件"],
                "warnings": [],
                "infoPlistFound": false
            ])
        }
    }

    private func sendIPAReport(_ report: [String: Any]) {
        guard let data = try? JSONSerialization.data(withJSONObject: report),
              let json = String(data: data, encoding: .utf8) else { return }
        DispatchQueue.main.async {
            self.webView.evaluateJavaScript("receiveIPAReport(\(json));", completionHandler: nil)
        }
    }

    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.banner, .sound, .badge])
    }

    deinit {
        webView?.configuration.userContentController.removeScriptMessageHandler(forName: "shareFile")
        webView?.configuration.userContentController.removeScriptMessageHandler(forName: "requestNotification")
        webView?.configuration.userContentController.removeScriptMessageHandler(forName: "deviceHealth")
        webView?.configuration.userContentController.removeScriptMessageHandler(forName: "pickIPA")
    }
}


private enum IPAInspector {
    private static let eocd: UInt32 = 0x06054b50
    private static let central: UInt32 = 0x02014b50
    private static let local: UInt32 = 0x04034b50

    private typealias Entry = (name: String, method: UInt16, compressed: Int, uncompressed: Int, localOffset: Int)

    static func inspect(data: Data, filename: String) throws -> [String: Any] {
        var result: [String: Any] = [
            "filename": filename,
            "fileSize": data.count,
            "entryCount": 0,
            "appFound": false,
            "infoPlistFound": false,
            "issues": [],
            "warnings": []
        ]

        guard let eocdOffset = findSignature(data, signature: eocd, fromEnd: true) else {
            throw NSError(domain: "IPAInspector", code: 301, userInfo: [NSLocalizedDescriptionKey: "解析失败：不是有效的 ZIP/IPA 文件"])
        }

        guard eocdOffset + 22 <= data.count else {
            throw NSError(domain: "IPAInspector", code: 302, userInfo: [NSLocalizedDescriptionKey: "解析失败：ZIP 文件末尾信息不完整"])
        }

        let count16 = Int(readUInt16(data, eocdOffset + 10))
        let centralSize = Int(readUInt32(data, eocdOffset + 12))
        let centralOffset = Int(readUInt32(data, eocdOffset + 16))

        // 目前不依赖目录条目数量来判断 App。只要中央目录可读取，就逐条扫描。
        // ZIP64 使用 0xFFFF/0xFFFFFFFF 哨兵值；遇到这种情况给出明确提示，而不是抛英文错误。
        if count16 == 0xFFFF || centralSize == Int(UInt32.max) || centralOffset == Int(UInt32.max) {
            throw NSError(domain: "IPAInspector", code: 303, userInfo: [NSLocalizedDescriptionKey: "解析失败：这个 IPA 使用 ZIP64 格式，当前版本暂不支持"])
        }

        guard centralOffset >= 0, centralSize >= 0,
              centralOffset <= data.count,
              centralSize <= data.count - centralOffset else {
            throw NSError(domain: "IPAInspector", code: 302, userInfo: [NSLocalizedDescriptionKey: "解析失败：ZIP 中央目录位置异常，文件可能不完整"])
        }

        let entries = parseCentralDirectory(data: data, offset: centralOffset, size: centralSize, expectedCount: count16)
        guard !entries.isEmpty || count16 == 0 else {
            throw NSError(domain: "IPAInspector", code: 303, userInfo: [NSLocalizedDescriptionKey: "解析失败：无法读取 ZIP 文件目录。请确认选择的是完整的 .ipa 文件"])
        }
        result["entryCount"] = entries.count

        var issues = [String]()
        var warnings = [String]()

        // 不要求 ZIP 必须存在 Payload/xxx.app/ 目录条目；很多打包器只写文件条目。
        var appRoots = Set<String>()
        for entry in entries {
            let parts = entry.name.split(separator: "/").map(String.init)
            guard parts.count >= 2, parts[0] == "Payload" else { continue }
            guard parts[1].hasSuffix(".app") else { continue }
            appRoots.insert("Payload/" + parts[1])
        }

        let sortedAppRoots = appRoots.sorted()
        let mainAppRoot = sortedAppRoots.first
        let hasPayloadEntries = entries.contains { $0.name == "Payload" || $0.name == "Payload/" || $0.name.hasPrefix("Payload/") }

        if let appRoot = mainAppRoot {
            result["appFound"] = true
            result["appPath"] = appRoot + "/"
            result["appRoot"] = appRoot
            if sortedAppRoots.count > 1 {
                result["appCount"] = sortedAppRoots.count
                warnings.append("发现 \(sortedAppRoots.count) 个 App，已选择 Payload 下的第一个主 App 进行分析")
            }
        } else {
            issues.append("没有找到标准的 Payload/*.app 结构")
        }

        if !hasPayloadEntries {
            issues.append("缺少 Payload 目录")
        }

        if let appRoot = mainAppRoot {
            let prefix = appRoot + "/"
            let infoCandidates = entries.filter { entry in
                entry.name == prefix + "Info.plist" || entry.name == prefix + "Info.plist/"
            }

            if let info = infoCandidates.first {
                if let plistData = extractEntry(data: data, entry: info),
                   let plistObject = try? PropertyListSerialization.propertyList(from: plistData, options: [], format: nil),
                   let plist = plistObject as? [String: Any] {
                    result["infoPlistFound"] = true
                    result["infoPlist"] = "已读取"
                    if let n = plist["CFBundleDisplayName"] as? String, !n.isEmpty {
                        result["appName"] = n
                    } else if let n = plist["CFBundleName"] as? String, !n.isEmpty {
                        result["appName"] = n
                    }
                    if let b = plist["CFBundleIdentifier"] as? String { result["bundleID"] = b }
                    if let v = plist["CFBundleShortVersionString"] as? String { result["version"] = v }
                    if let b = plist["CFBundleVersion"] as? String { result["build"] = b }

                    if let executable = plist["CFBundleExecutable"] as? String, !executable.isEmpty {
                        if let exec = entries.first(where: { $0.name == prefix + executable }),
                           let execData = extractEntry(data: data, entry: exec) {
                            result["arch"] = detectMachOArchitectures(execData) ?? "无法识别"
                        } else {
                            warnings.append("Info.plist 已读取，但未找到对应的主程序文件")
                        }
                    } else {
                        warnings.append("Info.plist 已读取，但没有 CFBundleExecutable")
                    }
                } else {
                    issues.append("找到了 Info.plist，但无法解析其内容。可能是文件损坏或格式异常")
                }
            } else {
                issues.append("未找到主 App 内的 Info.plist")
            }
        }

        if entries.contains(where: { $0.name.hasSuffix(".app/embedded.mobileprovision") || $0.name.hasSuffix(".app/embedded.mobileprovision/") }) {
            result["hasProvisioningProfile"] = true
            warnings.append("IPA 内包含 embedded.mobileprovision；这不代表 TrollStore 一定无法安装")
        }

        result["issues"] = issues
        result["warnings"] = warnings
        return result
    }

    private static func parseCentralDirectory(data: Data, offset: Int, size: Int, expectedCount: Int) -> [Entry] {
        var entries = [Entry]()
        var cursor = offset
        let end = offset + size
        var guardCount = 0

        while cursor + 46 <= end && guardCount < max(expectedCount, 1) {
            guard readUInt32(data, cursor) == central else { break }

            let method = readUInt16(data, cursor + 10)
            let compressed32 = readUInt32(data, cursor + 20)
            let uncompressed32 = readUInt32(data, cursor + 24)
            let nameLen = Int(readUInt16(data, cursor + 28))
            let extraLen = Int(readUInt16(data, cursor + 30))
            let commentLen = Int(readUInt16(data, cursor + 32))
            let localOffset32 = readUInt32(data, cursor + 42)
            let recordEnd = cursor + 46 + nameLen + extraLen + commentLen

            guard recordEnd <= end, recordEnd <= data.count else { break }

            let nameData = data.subdata(in: (cursor + 46)..<(cursor + 46 + nameLen))
            let name = String(data: nameData, encoding: .utf8) ?? String(data: nameData, encoding: .ascii) ?? ""

            // 这里暂时跳过 ZIP64 单个条目，避免把 64 位大小误当成 32 位导致越界。
            guard compressed32 != UInt32.max, uncompressed32 != UInt32.max, localOffset32 != UInt32.max,
                  localOffset32 < UInt32(data.count) else {
                cursor = recordEnd
                guardCount += 1
                continue
            }

            entries.append((name: name,
                            method: method,
                            compressed: Int(compressed32),
                            uncompressed: Int(uncompressed32),
                            localOffset: Int(localOffset32)))
            cursor = recordEnd
            guardCount += 1
        }
        return entries
    }

    private static func extractEntry(data: Data, entry: Entry) -> Data? {
        let o = entry.localOffset
        guard o >= 0, o + 30 <= data.count, readUInt32(data, o) == local else { return nil }
        let nameLen = Int(readUInt16(data, o + 26))
        let extraLen = Int(readUInt16(data, o + 28))
        let start = o + 30 + nameLen + extraLen
        guard start >= 0, entry.compressed >= 0, start <= data.count,
              entry.compressed <= data.count - start else { return nil }
        let payload = data.subdata(in: start..<(start + entry.compressed))
        if entry.method == 0 { return payload }
        if entry.method == 8 { return inflateRaw(payload, expectedSize: entry.uncompressed) }
        return nil
    }

    private static func inflateRaw(_ data: Data, expectedSize: Int) -> Data? {
        guard !data.isEmpty else { return Data() }
        var stream = z_stream()
        let initial = max(expectedSize, 4096)
        var output = Data(count: initial)

        let status: Int32 = output.withUnsafeMutableBytes { outPtr in
            data.withUnsafeBytes { inPtr in
                guard let inBase = inPtr.bindMemory(to: Bytef.self).baseAddress,
                      let outBase = outPtr.bindMemory(to: Bytef.self).baseAddress else { return Z_DATA_ERROR }
                stream.next_in = UnsafeMutablePointer<Bytef>(mutating: inBase)
                stream.avail_in = uInt(data.count)
                stream.next_out = outBase
                stream.avail_out = uInt(output.count)
                guard inflateInit2_(&stream, -MAX_WBITS) == Z_OK else { return Z_DATA_ERROR }
                var s = inflate(&stream, Z_FINISH)
                inflateEnd(&stream)
                if s == Z_BUF_ERROR && stream.avail_out == 0 {
                    return Z_BUF_ERROR
                }
                return s == Z_STREAM_END || s == Z_OK ? Z_OK : s
            }
        }

        guard status == Z_OK else { return nil }
        output.count = Int(stream.total_out)
        return output
    }

    private static func detectMachOArchitectures(_ data: Data) -> String? {
        guard data.count >= 4 else { return nil }
        let magic = readUInt32(data, 0)
        switch magic {
        case 0xFEEDFACF, 0xCFFAEDFE:
            return "Mach-O 64 位 / 单架构"
        case 0xCAFEBABE, 0xBEBAFECA:
            return "Universal / 多架构"
        default:
            return nil
        }
    }

    private static func findSignature(_ data: Data, signature: UInt32, fromEnd: Bool) -> Int? {
        guard data.count >= 4 else { return nil }
        if fromEnd {
            var i = data.count - 4
            while true {
                if readUInt32(data, i) == signature { return i }
                if i == 0 { break }
                i -= 1
            }
        } else {
            var i = 0
            while i + 4 <= data.count {
                if readUInt32(data, i) == signature { return i }
                i += 1
            }
        }
        return nil
    }

    private static func readUInt16(_ data: Data, _ offset: Int) -> UInt16 {
        guard offset >= 0, offset + 2 <= data.count else { return 0 }
        return UInt16(data[offset]) | (UInt16(data[offset + 1]) << 8)
    }

    private static func readUInt32(_ data: Data, _ offset: Int) -> UInt32 {
        guard offset >= 0, offset + 4 <= data.count else { return 0 }
        return UInt32(data[offset]) |
            (UInt32(data[offset + 1]) << 8) |
            (UInt32(data[offset + 2]) << 16) |
            (UInt32(data[offset + 3]) << 24)
    }
}

