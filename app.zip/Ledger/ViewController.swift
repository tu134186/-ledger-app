import UIKit
import WebKit
import WidgetKit
import UserNotifications

class ViewController: UIViewController, WKScriptMessageHandler, WKNavigationDelegate, UNUserNotificationCenterDelegate {
    var webView: WKWebView!
    let appGroupID = "group.com.diy.ledger"

    override func viewDidLoad() {
        super.viewDidLoad()
        let config = WKWebViewConfiguration()
        let userController = WKUserContentController()
        userController.add(self, name: "syncLedger")
        userController.add(self, name: "syncDad")
        userController.add(self, name: "setReminder")
        userController.add(self, name: "requestNotification")
        config.userContentController = userController
        webView = WKWebView(frame: view.bounds, configuration: config)
        webView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        webView.navigationDelegate = self
        webView.isOpaque = false
        webView.backgroundColor = .clear
        webView.scrollView.bounces = false
        view.addSubview(webView)
        if let url = Bundle.main.url(forResource: "index", withExtension: "html") {
            webView.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
        }
        NotificationCenter.default.addObserver(self, selector: #selector(appWillEnterForeground), name: UIApplication.willEnterForegroundNotification, object: nil)
        UNUserNotificationCenter.current().delegate = self
    }

    @objc func appWillEnterForeground() {
        WidgetCenter.shared.reloadAllTimelines()
    }

    func handleDeepLink(_ url: URL) {
        let host = url.host ?? ""
        var page = "index"
        if host == "ledger" { page = "ledger" }
        else if host == "dad" { page = "dad" }
        if let fileURL = Bundle.main.url(forResource: page, withExtension: "html") {
            webView.loadFileURL(fileURL, allowingReadAccessTo: fileURL.deletingLastPathComponent())
        }
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        if message.name == "setReminder" {
            setupDailyReminder(body: message.body as? String ?? "该记账啦")
            return
        }
        if message.name == "requestNotification" {
            UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { _, _ in }
            return
        }
        guard let json = message.body as? String else { return }
        let fileName: String
        if message.name == "syncLedger" { fileName = "ledger.json" }
        else if message.name == "syncDad" { fileName = "dad.json" }
        else { return }
        if let container = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: appGroupID) {
            let fileURL = container.appendingPathComponent(fileName)
            try? json.write(to: fileURL, atomically: true, encoding: .utf8)
        }
        WidgetCenter.shared.reloadAllTimelines()
    }

    func setupDailyReminder(body: String) {
        UNUserNotificationCenter.current().removeAllPendingNotificationRequests()
        let content = UNMutableNotificationContent()
        content.title = "记账提醒"
        content.body = body
        content.sound = .default
        var dateComponents = DateComponents()
        dateComponents.hour = 20
        dateComponents.minute = 0
        let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: true)
        let request = UNNotificationRequest(identifier: "dailyReminder", content: content, trigger: trigger)
        UNUserNotificationCenter.current().add(request)
    }

    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.banner, .sound])
    }

    override var prefersStatusBarHidden: Bool { false }
    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }
}
