import UIKit
import WebKit
import UserNotifications

final class ViewController: UIViewController, WKNavigationDelegate, WKScriptMessageHandler, UNUserNotificationCenterDelegate {
    private var webView: WKWebView!

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white

        let configuration = WKWebViewConfiguration()
        let userContentController = WKUserContentController()
        userContentController.add(self, name: "shareFile")
        userContentController.add(self, name: "requestNotification")
        userContentController.add(self, name: "deviceHealth")
        configuration.userContentController = userContentController

        webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = self
        webView.translatesAutoresizingMaskIntoConstraints = false
        webView.scrollView.bounces = false
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.scrollView.alwaysBounceVertical = false
        webView.scrollView.alwaysBounceHorizontal = false
        webView.scrollView.showsVerticalScrollIndicator = false
        webView.scrollView.showsHorizontalScrollIndicator = false
        webView.isOpaque = true
        webView.backgroundColor = .white
        view.addSubview(webView)

        NSLayoutConstraint.activate([
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            webView.topAnchor.constraint(equalTo: view.topAnchor),
            webView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])

        UNUserNotificationCenter.current().delegate = self
        loadHome()
    }

    private func loadHome() {
        guard let url = Bundle.main.url(forResource: "index", withExtension: "html") else { return }
        webView.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
    }

    func handleDeepLink(_ url: URL) {
        // Keep the scheme available for future toolbox shortcuts, but always return to the toolbox home.
        loadHome()
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        switch message.name {
        case "requestNotification":
            UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { _, _ in }
        case "deviceHealth":
            let iosVersion = UIDevice.current.systemVersion
            let model = UIDevice.current.model
            let appVersion = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "未知"
            let build = Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "未知"
            let trollstoreURL = URL(string: "trollstore://")!
            let trollstoreInstalled = UIApplication.shared.canOpenURL(trollstoreURL)
            let payload: [String: Any] = [
                "iosVersion": iosVersion,
                "deviceModel": model,
                "appVersion": appVersion,
                "build": build,
                "trollstoreInstalled": trollstoreInstalled,
                "webKit": true
            ]
            if let data = try? JSONSerialization.data(withJSONObject: payload),
               let json = String(data: data, encoding: .utf8) {
                DispatchQueue.main.async {
                    self.webView.evaluateJavaScript("window.receiveDeviceHealth(\(json));", completionHandler: nil)
                }
            }

        case "shareFile":
            guard let data = message.body as? [String: String],
                  let content = data["content"],
                  let filename = data["filename"] else { return }
            let fileURL = FileManager.default.temporaryDirectory.appendingPathComponent(filename)
            do {
                try content.write(to: fileURL, atomically: true, encoding: .utf8)
                let controller = UIActivityViewController(activityItems: [fileURL], applicationActivities: nil)
                controller.popoverPresentationController?.sourceView = view
                present(controller, animated: true)
            } catch {
                return
            }
        default:
            break
        }
    }

    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.banner, .sound, .badge])
    }

    deinit {
        webView?.configuration.userContentController.removeScriptMessageHandler(forName: "shareFile")
        webView?.configuration.userContentController.removeScriptMessageHandler(forName: "requestNotification")
        webView?.configuration.userContentController.removeScriptMessageHandler(forName: "deviceHealth")
    }
}
