import UIKit
import WebKit
import UserNotifications
import UniformTypeIdentifiers
import zlib

final class ViewController: UIViewController, WKNavigationDelegate, WKScriptMessageHandler, UNUserNotificationCenterDelegate, UIDocumentPickerDelegate {
    private var webView: WKWebView!

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white

        let configuration = WKWebViewConfiguration()
        let userContentController = WKUserContentController()
        userContentController.add(self, name: "shareFile")
        userContentController.add(self, name: "requestNotification")
        userContentController.add(self, name: "deviceHealth")
        userContentController.add(self, name: "pickIPA")
        configuration.userContentController = userContentController

        webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = self
        webView.translatesAutoresizingMaskIntoConstraints = false
        webView.scrollView.bounces = false
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.scrollView.alwaysBounceVertical = false
        webView.scrollView.alwaysBounceHorizontal = false
        webView.scrollView.showsVerticalScrollIndicator = false
        webView.scrollView.showsHorizontalScrollIndicator = false
        webView.isOpaque = true
        webView.backgroundColor = .white
        view.addSubview(webView)

        NSLayoutConstraint.activate([
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            webView.topAnchor.constraint(equalTo: view.topAnchor),
            webView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])

        UNUserNotificationCenter.current().delegate = self
        loadHome()
    }

    private func loadHome() {
        guard let url = Bundle.main.url(forResource: "index", withExtension: "html") else { return }
        webView.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
    }

    func handleDeepLink(_ url: URL) {
        // Keep the scheme available for future toolbox shortcuts, but always return to the toolbox home.
        loadHome()
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        switch message.name {
        case "requestNotification":
            UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { _, _ in }
        case "deviceHealth":
            let iosVersion = UIDevice.current.systemVersion
            let model = UIDevice.current.model
            let appVersion = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "未知"
            let build = Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "未知"

            // Prefer LaunchServices inspection: TrollStore 2 can use a randomized/stealth
            // bundle identifier, so checking only one URL scheme is not reliable.
            var trollstoreInstalled = false
            var trollstoreDetection = "未检测到"
            if let workspaceClass = NSClassFromString("LSApplicationWorkspace") as? NSObject.Type,
               let workspace = workspaceClass.perform(NSSelectorFromString("defaultWorkspace"))?.takeUnretainedValue() as? NSObject,
               let apps = workspace.perform(NSSelectorFromString("allApplications"))?.takeUnretainedValue() as? [AnyObject] {
                for item in apps {
                    guard let app = item as? NSObject else { continue }
                    let bundleID = (app.value(forKey: "applicationIdentifier") as? String) ?? (app.value(forKey: "bundleIdentifier") as? String) ?? ""
                    let name = (app.value(forKey: "localizedName") as? String) ?? ""
                    if bundleID == "com.opa334.TrollStore" || bundleID.hasPrefix("com.opa334.TrollStore.TS_") || name.caseInsensitiveCompare("TrollStore") == .orderedSame {
                        trollstoreInstalled = true
                        trollstoreDetection = "通过系统应用列表检测到 TrollStore"
                        break
                    }
                }
            }

            // Fallbacks for environments where LaunchServices enumeration is restricted.
            let legacySchemeAvailable = UIApplication.shared.canOpenURL(URL(string: "trollstore://")!)
            if !trollstoreInstalled && legacySchemeAvailable {
                trollstoreInstalled = true
                trollstoreDetection = "检测到 TrollStore URL Scheme"
            }
            let magnifierSchemeAvailable = UIApplication.shared.canOpenURL(URL(string: "apple-magnifier://")!)
            if !trollstoreInstalled && magnifierSchemeAvailable {
                trollstoreDetection = "检测到系统 apple-magnifier://，无法单独证明 TrollStore 已安装"
            }

            let payload: [String: Any] = [
                "iosVersion": iosVersion,
                "deviceModel": model,
                "appVersion": appVersion,
                "build": build,
                "trollstoreInstalled": trollstoreInstalled,
                "trollstoreDetection": trollstoreDetection,
                "trollstoreSchemeState": legacySchemeAvailable ? "legacy" : (magnifierSchemeAvailable ? "apple-magnifier" : "none"),
                "webKit": true
            ]


        case "pickIPA":
            let picker = UIDocumentPickerViewController(forOpeningContentTypes: [UTType(filenameExtension: "ipa") ?? .data], asCopy: true)
            picker.delegate = self
            picker.allowsMultipleSelection = false
            present(picker, animated: true)

        case "shareFile":
            guard let data = message.body as? [String: String],
                  let content = data["content"],
                  let filename = data["filename"] else { return }
            let fileURL = FileManager.default.temporaryDirectory.appendingPathComponent(filename)
            do {
                try content.write(to: fileURL, atomically: true, encoding: .utf8)
                let controller = UIActivityViewController(activityItems: [fileURL], applicationActivities: nil)
                controller.popoverPresentationController?.sourceView = view
                present(controller, animated: true)
            } catch {
                return
            }
        default:
            break
        }
    }


    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let url = urls.first else { return }
        do {
            let data = try Data(contentsOf: url)
            let report = try IPAInspector.inspect(data: data, filename: url.lastPathComponent)
            sendIPAReport(report)
        } catch {
            sendIPAReport([
                "filename": url.lastPathComponent,
                "fileSize": 0,
                "entryCount": 0,
                "appFound": false,
                "issues": ["无法读取 IPA：\(error.localizedDescription)"],
                "warnings": [],
                "infoPlistFound": false
            ])
        }
    }

    private func sendIPAReport(_ report: [String: Any]) {
        guard let data = try? JSONSerialization.data(withJSONObject: report),
              let json = String(data: data, encoding: .utf8) else { return }
        DispatchQueue.main.async {
            self.webView.evaluateJavaScript("receiveIPAReport(\(json));", completionHandler: nil)
        }
    }

    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.banner, .sound, .badge])
    }

    deinit {
        webView?.configuration.userContentController.removeScriptMessageHandler(forName: "shareFile")
        webView?.configuration.userContentController.removeScriptMessageHandler(forName: "requestNotification")
        webView?.configuration.userContentController.removeScriptMessageHandler(forName: "deviceHealth")
        webView?.configuration.userContentController.removeScriptMessageHandler(forName: "pickIPA")
    }
}


private enum IPAInspector {
    private static let eocd: UInt32 = 0x06054b50
    private static let central: UInt32 = 0x02014b50
    private static let local: UInt32 = 0x04034b50

    static func inspect(data: Data, filename: String) throws -> [String: Any] {
        var result: [String: Any] = [
            "filename": filename,
            "fileSize": data.count,
            "entryCount": 0,
            "appFound": false,
            "infoPlistFound": false,
            "issues": [],
            "warnings": []
        ]

        guard let eocdOffset = findSignature(data, signature: eocd, fromEnd: true) else {
            throw NSError(domain: "IPAInspector", code: 1, userInfo: [NSLocalizedDescriptionKey: "不是有效的 ZIP/IPA 文件"])
        }

        let count = Int(readUInt16(data, eocdOffset + 10))
        let centralSize = Int(readUInt32(data, eocdOffset + 12))
        let centralOffset = Int(readUInt32(data, eocdOffset + 16))
        if centralOffset + centralSize > data.count {
            throw NSError(domain: "IPAInspector", code: 2, userInfo: [NSLocalizedDescriptionKey: "ZIP 中央目录损坏"])
        }

        var entries: [(name: String, method: UInt16, compressed: Int, uncompressed: Int, localOffset: Int)] = []
        var p = centralOffset
        for _ in 0..<count {
            guard p + 46 <= data.count, readUInt32(data, p) == central else { break }
            let method = readUInt16(data, p + 10)
            let compressed = Int(readUInt32(data, p + 20))
            let uncompressed = Int(readUInt32(data, p + 24))
            let nameLen = Int(readUInt16(data, p + 28))
            let extraLen = Int(readUInt16(data, p + 30))
            let commentLen = Int(readUInt16(data, p + 32))
            let localOffset = Int(readUInt32(data, p + 42))
            guard p + 46 + nameLen + extraLen + commentLen <= data.count else { break }
            let nameData = data.subdata(in: (p + 46)..<(p + 46 + nameLen))
            let name = String(data: nameData, encoding: .utf8) ?? String(decoding: nameData, as: UTF8.self)
            entries.append((name, method, compressed, uncompressed, localOffset))
            p += 46 + nameLen + extraLen + commentLen
        }

        result["entryCount"] = entries.count
        var issues = [String]()
        var warnings = [String]()
        let apps = entries.filter { $0.name.hasPrefix("Payload/") && $0.name.hasSuffix(".app/") }
        let appFile = entries.first { $0.name.hasPrefix("Payload/") && $0.name.hasSuffix(".app") && !$0.name.hasSuffix(".app/") }
        let appPath: String?
        if !apps.isEmpty {
            appPath = apps[0].name
        } else if let f = appFile {
            appPath = f.name
        } else {
            appPath = nil
        }

        if let appPath = appPath {
            result["appFound"] = true
            result["appPath"] = appPath
        } else {
            issues.append("没有找到 Payload/*.app 结构")
        }

        if !entries.contains(where: { $0.name.hasPrefix("Payload/") }) {
            issues.append("缺少 Payload 目录")
        }
        if entries.contains(where: { $0.name.hasSuffix(".app/") }) == false {
            warnings.append("没有识别到标准 .app 目录条目，可能是异常打包方式")
        }

        // Locate Info.plist inside the first app.
        if let appDir = apps.first?.name ?? appFile?.name {
            let prefix = appDir.hasSuffix("/") ? appDir : appDir + "/"
            if let info = entries.first(where: { $0.name == prefix + "Info.plist" }) {
                if let plistData = extractEntry(data: data, entry: info),
                   let plist = try? PropertyListSerialization.propertyList(from: plistData, options: [], format: nil) as? [String: Any] {
                    result["infoPlistFound"] = true
                    if let n = plist["CFBundleDisplayName"] as? String ?? plist["CFBundleName"] as? String { result["appName"] = n }
                    if let b = plist["CFBundleIdentifier"] as? String { result["bundleID"] = b }
                    if let v = plist["CFBundleShortVersionString"] as? String { result["version"] = v }
                    if let b = plist["CFBundleVersion"] as? String { result["build"] = b }
                    if let e = plist["CFBundleExecutable"] as? String {
                        let execEntry = entries.first(where: { $0.name == prefix + e })
                        if let exec = execEntry, let execData = extractEntry(data: data, entry: exec) {
                            result["arch"] = detectMachOArchitectures(execData)
                        }
                    }
                } else {
                    warnings.append("找到了 Info.plist，但当前压缩方式无法在本机解压读取")
                }
            } else {
                warnings.append("未找到 Payload/*.app/Info.plist")
            }
        }

        if entries.contains(where: { $0.name.hasSuffix(".app/embedded.mobileprovision") }) {
            result["hasProvisioningProfile"] = true
            warnings.append("IPA 内包含 embedded.mobileprovision；这不等于 TrollStore 一定无法安装")
        }

        let compressedEntries = entries.filter { $0.method == 8 }.count
        if compressedEntries > 0 && result["infoPlistFound"] == nil {
            warnings.append("IPA 使用 Deflate 压缩；部分深度信息可能无法直接读取")
        }

        result["issues"] = issues
        result["warnings"] = warnings
        return result
    }

    private static func extractEntry(data: Data, entry: (name: String, method: UInt16, compressed: Int, uncompressed: Int, localOffset: Int)) -> Data? {
        let o = entry.localOffset
        guard o + 30 <= data.count, readUInt32(data, o) == local else { return nil }
        let nameLen = Int(readUInt16(data, o + 26))
        let extraLen = Int(readUInt16(data, o + 28))
        let start = o + 30 + nameLen + extraLen
        guard start + entry.compressed <= data.count else { return nil }
        let payload = data.subdata(in: start..<(start + entry.compressed))
        if entry.method == 0 { return payload }
        // ZIP Deflate is raw DEFLATE. Use zlib's inflateInit2 with a negative window size.
        if entry.method == 8 {
            return inflateRaw(payload, expectedSize: entry.uncompressed)
        }
        return nil
    }

    private static func inflateRaw(_ data: Data, expectedSize: Int) -> Data? {
        var stream = z_stream()
        var output = Data(count: max(expectedSize, 1024))
        var result: Data?
        let status: Int32 = output.withUnsafeMutableBytes { outPtr in
            data.withUnsafeBytes { inPtr in
                stream.next_in = UnsafeMutablePointer<Bytef>(mutating: inPtr.bindMemory(to: Bytef.self).baseAddress)
                stream.avail_in = uInt(data.count)
                stream.next_out = outPtr.bindMemory(to: Bytef.self).baseAddress
                stream.avail_out = uInt(output.count)
                guard inflateInit2_(&stream, -MAX_WBITS) == Z_OK else { return Z_DATA_ERROR }
                let s = inflate(&stream, Z_FINISH)
                inflateEnd(&stream)
                if s == Z_STREAM_END || s == Z_OK {
                    return Z_OK
                }
                return s
            }
        }
        if status == Z_OK {
            output.count = Int(stream.total_out)
            result = output
        }
        return result
    }

    private static func detectMachOArchitectures(_ data: Data) -> String? {
        guard data.count >= 4 else { return nil }
        let magic = readUInt32(data, 0)
        switch magic {
        case 0xFEEDFACF, 0xCFFAEDFE:
            return "arm64 / 单架构"
        case 0xCAFEBABE, 0xBEBAFECA:
            return "Universal / 多架构"
        default:
            return nil
        }
    }

    private static func findSignature(_ data: Data, signature: UInt32, fromEnd: Bool) -> Int? {
        guard data.count >= 4 else { return nil }
        if fromEnd {
            var i = data.count - 4
            while true {
                if readUInt32(data, i) == signature { return i }
                if i == 0 { break }
                i -= 1
            }
        } else {
            var i = 0
            while i + 4 <= data.count {
                if readUInt32(data, i) == signature { return i }
                i += 1
            }
        }
        return nil
    }

    private static func readUInt16(_ data: Data, _ offset: Int) -> UInt16 {
        guard offset + 2 <= data.count else { return 0 }
        return UInt16(data[offset]) | (UInt16(data[offset + 1]) << 8)
    }

    private static func readUInt32(_ data: Data, _ offset: Int) -> UInt32 {
        guard offset + 4 <= data.count else { return 0 }
        return UInt32(data[offset]) |
            (UInt32(data[offset + 1]) << 8) |
            (UInt32(data[offset + 2]) << 16) |
            (UInt32(data[offset + 3]) << 24)
    }
}
