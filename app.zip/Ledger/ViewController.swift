import UIKit
import WebKit
import WidgetKit

class ViewController: UIViewController, WKScriptMessageHandler, WKNavigationDelegate {
    var webView: WKWebView!
    let appGroupID = "group.com.diy.ledger"

    override func viewDidLoad() {
        super.viewDidLoad()
        let config = WKWebViewConfiguration()
        let userController = WKUserContentController()
        userController.add(self, name: "syncLedger")
        userController.add(self, name: "syncDad")
        config.userContentController = userController
        webView = WKWebView(frame: view.bounds, configuration: config)
        webView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        webView.navigationDelegate = self
        webView.isOpaque = false
        webView.backgroundColor = .clear
        webView.scrollView.bounces = false
        view.addSubview(webView)
        if let url = Bundle.main.url(forResource: "index", withExtension: "html") {
            webView.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
        }
    }

    func handleDeepLink(_ url: URL) {
        let host = url.host ?? ""
        var page = "index"
        if host == "ledger" { page = "ledger" }
        else if host == "dad" { page = "dad" }
        if let fileURL = Bundle.main.url(forResource: page, withExtension: "html") {
            webView.loadFileURL(fileURL, allowingReadAccessTo: fileURL.deletingLastPathComponent())
        }
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard let json = message.body as? String else { return }
        let fileName: String
        if message.name == "syncLedger" { fileName = "ledger.json" }
        else if message.name == "syncDad" { fileName = "dad.json" }
        else { return }
        if let container = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: appGroupID) {
            let fileURL = container.appendingPathComponent(fileName)
            try? json.write(to: fileURL, atomically: true, encoding: .utf8)
        }
        WidgetCenter.shared.reloadAllTimelines()
    }

    override var prefersStatusBarHidden: Bool { false }
    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }
}
