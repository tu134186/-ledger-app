import UIKit
import WebKit
import WidgetKit
import UserNotifications
import Vision
import Photos

class ViewController: UIViewController, WKScriptMessageHandler, WKNavigationDelegate, UNUserNotificationCenterDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    var webView: WKWebView!
    let appGroupID = "group.com.diy.ledger"
    var pendingAddParams: [String: String]?

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 0.961, green: 0.961, blue: 0.969, alpha: 1.0)

        let config = WKWebViewConfiguration()
        let userController = WKUserContentController()
        userController.add(self, name: "syncLedger")
        userController.add(self, name: "setReminder")
        userController.add(self, name: "requestNotification")
        userController.add(self, name: "iCloudBackup")
        userController.add(self, name: "iCloudRestore")
        userController.add(self, name: "recognizeScreenshot")
        userController.add(self, name: "shareFile")
        config.userContentController = userController

        webView = WKWebView(frame: view.bounds, configuration: config)
        webView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        webView.navigationDelegate = self
        webView.isOpaque = false
        webView.backgroundColor = UIColor(red: 0.961, green: 0.961, blue: 0.969, alpha: 1.0)
        webView.scrollView.backgroundColor = UIColor(red: 0.961, green: 0.961, blue: 0.969, alpha: 1.0)
        webView.scrollView.bounces = true
        webView.scrollView.alwaysBounceVertical = true
        webView.scrollView.showsVerticalScrollIndicator = false
        webView.scrollView.showsHorizontalScrollIndicator = false
        view.addSubview(webView)

        if let url = Bundle.main.url(forResource: "index", withExtension: "html") {
            webView.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
        }

        NotificationCenter.default.addObserver(self, selector: #selector(appWillEnterForeground), name: UIApplication.willEnterForegroundNotification, object: nil)
        UNUserNotificationCenter.current().delegate = self
    }

    @objc func appWillEnterForeground() {
        WidgetCenter.shared.reloadAllTimelines()
    }

    func handleDeepLink(_ url: URL) {
        let host = url.host ?? ""
        if host == "add" {
            let components = URLComponents(url: url, resolvingAgainstBaseURL: false)
            var params: [String: String] = [:]
            components?.queryItems?.forEach { params[$0.name] = $0.value ?? "" }
            pendingAddParams = params
            if let fileURL = Bundle.main.url(forResource: "ledger", withExtension: "html") {
                webView.loadFileURL(fileURL, allowingReadAccessTo: fileURL.deletingLastPathComponent())
            }
            return
        }
        var page = "index"
        if host == "ledger" { page = "ledger" }
        if let fileURL = Bundle.main.url(forResource: page, withExtension: "html") {
            webView.loadFileURL(fileURL, allowingReadAccessTo: fileURL.deletingLastPathComponent())
        }
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        if let params = pendingAddParams {
            let amount = params["amount"] ?? ""
            let category = params["category"] ?? ""
            let type = params["type"] ?? "out"
            let js = "if(window.quickAddFromShortcut){window.quickAddFromShortcut('\(amount)','\(category)','\(type)');}"
            webView.evaluateJavaScript(js, completionHandler: nil)
            pendingAddParams = nil
        }
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        if message.name == "setReminder" {
            setupDailyReminder(body: message.body as? String ?? "该记账啦")
            return
        }
        if message.name == "requestNotification" {
            UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { _, _ in }
            return
        }
        if message.name == "iCloudBackup" {
            if let json = message.body as? String {
                let store = NSUbiquitousKeyValueStore.default
                store.set(json, forKey: "ledger_backup")
                store.set(Date().timeIntervalSince1970, forKey: "ledger_backup_time")
                store.synchronize()
                webView.evaluateJavaScript("iCloudBackupResult(true)", completionHandler: nil)
            } else {
                webView.evaluateJavaScript("iCloudBackupResult(false)", completionHandler: nil)
            }
            return
        }
        if message.name == "iCloudRestore" {
            let store = NSUbiquitousKeyValueStore.default
            if let json = store.string(forKey: "ledger_backup") {
                // 完整转义：反斜杠、单引号、换行、回车、制表符、行分隔符、段落分隔符
                var escaped = json
                    .replacingOccurrences(of: "\\", with: "\\\\")
                    .replacingOccurrences(of: "'", with: "\\'")
                    .replacingOccurrences(of: "\n", with: "\\n")
                    .replacingOccurrences(of: "\r", with: "\\r")
                    .replacingOccurrences(of: "\t", with: "\\t")
                // 处理 Unicode 行分隔符和段落分隔符（JS 中会导致语法错误）
                escaped = escaped
                    .replacingOccurrences(of: "\u{2028}", with: "\\u2028")
                    .replacingOccurrences(of: "\u{2029}", with: "\\u2029")
                webView.evaluateJavaScript("iCloudRestoreResult('\(escaped)')", completionHandler: nil)
            } else {
                webView.evaluateJavaScript("iCloudRestoreResult(null)", completionHandler: nil)
            }
            return
        }
        if message.name == "recognizeScreenshot" {
            checkPhotoPermissionAndPick()
            return
        }
        if message.name == "shareFile" {
            if let dict = message.body as? [String: String],
               let content = dict["content"],
               let filename = dict["filename"] {
                let tempDir = FileManager.default.temporaryDirectory
                let fileURL = tempDir.appendingPathComponent(filename)
                do {
                    try content.write(to: fileURL, atomically: true, encoding: .utf8)
                    let activityVC = UIActivityViewController(activityItems: [fileURL], applicationActivities: nil)
                    activityVC.popoverPresentationController?.sourceView = view
                    present(activityVC, animated: true)
                } catch {
                    webView.evaluateJavaScript("toast('文件保存失败')", completionHandler: nil)
                }
            }
            return
        }
        guard let json = message.body as? String else { return }
        let fileName: String
        if message.name == "syncLedger" { fileName = "ledger.json" }
        else { return }

        if let container = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: appGroupID) {
            let fileURL = container.appendingPathComponent(fileName)
            do {
                try json.write(to: fileURL, atomically: true, encoding: .utf8)
            } catch {
                // 写入失败时不中断流程
            }
        }
        // 立即刷新小组件（秒级同步）
        WidgetCenter.shared.reloadAllTimelines()
        // 2秒后再刷新一次作为兜底，确保数据一定同步过去
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
            WidgetCenter.shared.reloadAllTimelines()
        }
    }

    // 检查照片权限，必要时请求后再打开选择器
    func checkPhotoPermissionAndPick() {
        let status = PHPhotoLibrary.authorizationStatus(for: .readWrite)
        switch status {
        case .authorized, .limited:
            openPhotoPicker()
        case .notDetermined:
            PHPhotoLibrary.requestAuthorization(for: .readWrite) { [weak self] newStatus in
                DispatchQueue.main.async {
                    if newStatus == .authorized || newStatus == .limited {
                        self?.openPhotoPicker()
                    } else {
                        self?.webView.evaluateJavaScript("toast('需要照片权限才能识别截图')", completionHandler: nil)
                        self?.webView.evaluateJavaScript("ocrResult(null)", completionHandler: nil)
                    }
                }
            }
        case .denied, .restricted:
            webView.evaluateJavaScript("toast('请在设置中开启照片权限')", completionHandler: nil)
            webView.evaluateJavaScript("ocrResult(null)", completionHandler: nil)
        @unknown default:
            openPhotoPicker()
        }
    }

    func openPhotoPicker() {
        let picker = UIImagePickerController()
        picker.sourceType = .photoLibrary
        picker.delegate = self
        present(picker, animated: true)
    }

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true)
        guard let image = info[.originalImage] as? UIImage, let cgImage = image.cgImage else {
            webView.evaluateJavaScript("ocrResult(null)", completionHandler: nil)
            return
        }
        let request = VNRecognizeTextRequest { [weak self] request, error in
            guard let observations = request.results as? [VNRecognizedTextObservation] else {
                DispatchQueue.main.async {
                    self?.webView.evaluateJavaScript("ocrResult(null)", completionHandler: nil)
                }
                return
            }
            var amounts: [String] = []
            for obs in observations {
                if let text = obs.topCandidates(1).first?.string {
                    // 匹配金额模式：¥ / $ / 数字.两位小数 / 数字元
                    let patterns = ["¥\\s*\\d+\\.?\\d*", "\\$\\s*\\d+\\.?\\d*", "\\d+\\.\\d{2}", "\\d+\\s*元"]
                    for pattern in patterns {
                        if let regex = try? NSRegularExpression(pattern: pattern) {
                            let matches = regex.matches(in: text, range: NSRange(text.startIndex..., in: text))
                            for match in matches {
                                if let range = Range(match.range, in: text) {
                                    var amountStr = String(text[range])
                                        .replacingOccurrences(of: "¥", with: "")
                                        .replacingOccurrences(of: "$", with: "")
                                        .replacingOccurrences(of: "元", with: "")
                                        .replacingOccurrences(of: " ", with: "")
                                    if Double(amountStr) != nil {
                                        amounts.append(amountStr)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            let result = amounts.first ?? ""
            DispatchQueue.main.async {
                let escaped = result.replacingOccurrences(of: "'", with: "\\'")
                self?.webView.evaluateJavaScript("ocrResult('\(escaped)')", completionHandler: nil)
            }
        }
        request.recognitionLevel = .accurate
        request.recognitionLanguages = ["zh-Hans", "en"]
        request.usesLanguageCorrection = true
        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
        try? handler.perform([request])
    }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true)
        webView.evaluateJavaScript("ocrResult(null)", completionHandler: nil)
    }

    func setupDailyReminder(body: String) {
        UNUserNotificationCenter.current().removeAllPendingNotificationRequests()
        let content = UNMutableNotificationContent()
        content.title = "记账提醒"
        content.body = body
        content.sound = .default
        var dateComponents = DateComponents()
        dateComponents.hour = 20
        dateComponents.minute = 0
        let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: true)
        let request = UNNotificationRequest(identifier: "dailyReminder", content: content, trigger: trigger)
        UNUserNotificationCenter.current().add(request)
    }

    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.banner, .sound])
    }

    override var prefersStatusBarHidden: Bool { false }
    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }
}
