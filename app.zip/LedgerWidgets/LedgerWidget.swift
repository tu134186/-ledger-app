import WidgetKit
import SwiftUI

let appGroupID = "group.com.diy.ledger"

// MARK: - Data Models
struct LedgerRecord: Codable {
    let id: String
    let type: String
    let category: String?
    let amount: Double
    let note: String?
    let time: Double
}

struct LedgerData: Codable {
    let records: [LedgerRecord]?
}

func loadJSON<T: Codable>(_ fileName: String, as type: T.Type) -> T? {
    guard let container = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: appGroupID) else { return nil }
    let url = container.appendingPathComponent(fileName)
    guard let data = try? Data(contentsOf: url) else { return nil }
    return try? JSONDecoder().decode(T.self, from: data)
}

// MARK: - 日常记账 Widget
struct LedgerProvider: TimelineProvider {
    func placeholder(in context: Context) -> LedgerEntry {
        LedgerEntry(date: Date(), todayIn: 0, todayOut: 0, monthIn: 0, monthOut: 0)
    }

    func getSnapshot(in context: Context, completion: @escaping (LedgerEntry) -> ()) {
        completion(placeholder(in: context))
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<LedgerEntry>) -> ()) {
        let data = loadJSON("ledger.json", as: LedgerData.self)
        let now = Date()
        var ti = 0.0, te = 0.0, mi = 0.0, me = 0.0

        if let records = data?.records {
            for r in records {
                let d = Date(timeIntervalSince1970: r.time / 1000)
                if Calendar.current.isDate(d, inSameDayAs: now) {
                    if r.type == "in" { ti += r.amount } else { te += r.amount }
                }
                if Calendar.current.isDate(d, equalTo: now, toGranularity: .month) {
                    if r.type == "in" { mi += r.amount } else { me += r.amount }
                }
            }
        }

        let entry = LedgerEntry(date: now, todayIn: ti, todayOut: te, monthIn: mi, monthOut: me)
        // 每15分钟系统自动刷新一次；App内保存数据时会主动触发 reloadAllTimelines()
        let next = Calendar.current.date(byAdding: .minute, value: 15, to: now) ?? now.addingTimeInterval(900)
        completion(Timeline(entries: [entry], policy: .after(next)))
    }
}

struct LedgerEntry: TimelineEntry {
    let date: Date
    let todayIn: Double
    let todayOut: Double
    let monthIn: Double
    let monthOut: Double
}

// 金额格式化：整数不显示小数，有小数时最多两位
func fmtAmount(_ v: Double) -> String {
    if v == Double(Int(v)) { return "\(Int(v))" }
    return String(format: "%.2f", v)
}

struct LedgerWidgetView: View {
    var entry: LedgerProvider.Entry

    private var todayBalance: Double { entry.todayIn - entry.todayOut }
    private var monthBalance: Double { entry.monthIn - entry.monthOut }
    private var monthTotal: Double { entry.monthIn + entry.monthOut }
    private var outRatio: Double {
        guard monthTotal > 0 else { return 0 }
        return min(max(entry.monthOut / monthTotal, 0), 1)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            // 顶部：标题 + 日期
            HStack(spacing: 6) {
                Image(systemName: "wallet.pass.fill")
                    .foregroundColor(.orange)
                    .font(.system(size: 13))
                Text("日常记账")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.primary)
                Spacer()
                Text(entry.date, format: .dateTime.month().day().weekday(.abbreviated))
                    .font(.system(size: 11))
                    .foregroundColor(.secondary)
            }
            .padding(.bottom, 12)

            // 中部：今日三栏数据
            HStack(alignment: .top, spacing: 4) {
                VStack(alignment: .leading, spacing: 3) {
                    Text("今日收入")
                        .font(.system(size: 10))
                        .foregroundColor(.secondary)
                    Text("¥\(fmtAmount(entry.todayIn))")
                        .font(.system(size: 17, weight: .heavy))
                        .foregroundColor(.green)
                        .lineLimit(1)
                        .minimumScaleFactor(0.7)
                }
                .frame(maxWidth: .infinity, alignment: .leading)

                VStack(alignment: .leading, spacing: 3) {
                    Text("今日支出")
                        .font(.system(size: 10))
                        .foregroundColor(.secondary)
                    Text("¥\(fmtAmount(entry.todayOut))")
                        .font(.system(size: 17, weight: .heavy))
                        .foregroundColor(.red)
                        .lineLimit(1)
                        .minimumScaleFactor(0.7)
                }
                .frame(maxWidth: .infinity, alignment: .leading)

                VStack(alignment: .leading, spacing: 3) {
                    Text("今日结余")
                        .font(.system(size: 10))
                        .foregroundColor(.secondary)
                    Text("¥\(fmtAmount(todayBalance))")
                        .font(.system(size: 17, weight: .heavy))
                        .foregroundColor(todayBalance >= 0 ? .orange : .red)
                        .lineLimit(1)
                        .minimumScaleFactor(0.7)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .padding(.bottom, 12)

            // 分割线
            Rectangle()
                .fill(Color(.systemGray5))
                .frame(height: 1)
                .padding(.bottom, 10)

            // 底部：本月概览 + 进度条
            HStack(alignment: .center, spacing: 10) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("本月概览")
                        .font(.system(size: 10))
                        .foregroundColor(.secondary)
                    // 进度条：支出占比
                    GeometryReader { geo in
                        ZStack(alignment: .leading) {
                            RoundedRectangle(cornerRadius: 3)
                                .fill(Color(.systemGray5))
                                .frame(height: 6)
                            RoundedRectangle(cornerRadius: 3)
                                .fill(LinearGradient(gradient: Gradient(colors: [Color(red: 1.0, green: 0.58, blue: 0.0), Color(red: 1.0, green: 0.42, blue: 0.0)]), startPoint: .leading, endPoint: .trailing))
                                .frame(width: geo.size.width * CGFloat(outRatio), height: 6)
                        }
                    }
                    .frame(height: 6)
                }
                .frame(maxWidth: .infinity, alignment: .leading)

                VStack(alignment: .trailing, spacing: 2) {
                    HStack(spacing: 6) {
                        Text("收")
                            .font(.system(size: 9))
                            .foregroundColor(.secondary)
                        Text("¥\(fmtAmount(entry.monthIn))")
                            .font(.system(size: 11, weight: .semibold))
                            .foregroundColor(.green)
                    }
                    HStack(spacing: 6) {
                        Text("支")
                            .font(.system(size: 9))
                            .foregroundColor(.secondary)
                        Text("¥\(fmtAmount(entry.monthOut))")
                            .font(.system(size: 11, weight: .semibold))
                            .foregroundColor(.red)
                    }
                }
            }
        }
        .padding(14)
        .widgetURL(URL(string: "ledger://ledger"))
    }
}

struct LedgerWidget: Widget {
    let kind: String = "LedgerWidget"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: LedgerProvider()) { entry in
            LedgerWidgetView(entry: entry)
        }
        .configurationDisplayName("日常记账")
        .description("显示今日和本月收支情况")
        .supportedFamilies([.systemMedium])
    }
}

@main
struct LedgerWidgets: WidgetBundle {
    var body: some Widget {
        LedgerWidget()
    }
}
